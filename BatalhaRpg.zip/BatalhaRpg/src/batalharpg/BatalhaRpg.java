
package batalharpg;

import personagens.Personagem;

public class BatalhaRpg {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Personagem p1 = new Personagem();
        Personagem p2 = new Personagem();
        
        
    }
    
}
